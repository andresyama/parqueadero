<?php
    header('Access-Control-Allow-Origin: *');
    header('Content-type: application/json');
    include('conexion.php');
    $mysqli = new mysqli($host, $user, $pw, $db);

    $sql1 = "SELECT * FROM ubicacion_parqueadero";
    $result1 = mysqli_query($mysqli, $sql1);

    $respuesta1 = $result1->fetch_array(MYSQLI_NUM);
    $respuesta2 = $result1->fetch_array(MYSQLI_NUM);
    $final = [$respuesta1,$respuesta2];
    
    $sqlpark1 = "SELECT COUNT(*) FROM estados_puestos WHERE (ocupacion = 0 && parqueadero = 1) ";
    $resultpark1 = $mysqli->query($sqlpark1);
    
    $sqlpark2 = "SELECT COUNT(*) FROM estados_puestos WHERE (ocupacion = 0 && parqueadero = 2) ";
    $resultpark2 = $mysqli->query($sqlpark2);
    
    $sql3 = "SELECT idParqueadero,valor_tarifa FROM tarifas";
    $result3 = $mysqli->query($sql3);
    
    $tarifa1 = $result3->fetch_array(MYSQLI_NUM);
    $tarifa2 = $result3->fetch_array(MYSQLI_NUM);
    $tarifa = [$tarifa1[1],$tarifa2[1]];
    
    $lugares_libres1 = $resultpark1->fetch_array(MYSQLI_NUM);
    $lugares_libres2 = $resultpark2->fetch_array(MYSQLI_NUM);
    
    if ($lugares_libres1===null) {
        $lugares_libres1 = array("0");
    }
    if ($lugares_libres2===null) {
        $lugares_libres2 = array("0");
    }
    
    $lugares_libres = [$lugares_libres1,$lugares_libres2];
    echo json_encode(array('resultado' => $final,'park1'=>$lugares_libres1,'tarifas'=>$tarifa, 'park2'=>$lugares_libres2 ));
?>
    
	
