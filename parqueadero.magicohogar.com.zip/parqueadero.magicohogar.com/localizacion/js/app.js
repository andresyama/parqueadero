document.addEventListener('DOMContentLoaded', ()=>{
        
});
let puestosLibres1=0;
let puestosLibres2=0;
let tarifa1, tarifa2;



function initMap() {
    const URL = "/localizacion/js/conexion_consulta_parqueaderos.php"
    fetch("js/conexion_consulta_parqueaderos.php")
        .then(Response => Response.json())
        .then(({resultado, park1, tarifas, park2}) => {
            
            tarifa1 = Number(tarifas[0]);
            tarifa2 = Number(tarifas[1]);
            
            puestosLibres1=park1[0];
            puestosLibres2=park2[0];
            
            iniciar(resultado);    
        })    
}

    function iniciar (ubicaciones) {
        const parqueadero1 = {lat: Number(ubicaciones[0][1]), lng: Number(ubicaciones[0][2])};
        const parqueadero2 = {lat: Number(ubicaciones[0][1]), lng: Number(ubicaciones[1][2])};
        const map = new google.maps.Map(document.getElementById('mapa'), {
            zoom: 15,
            center: parqueadero1,       
        });
    
        const contentString1 =
        '<div id="content">' +
        '<div id="siteNotice">' +
        "</div>" +
        '<h2 id="firstHeading" class="firstHeading">Parqueadero 1</h2>' +
        '<div id="bodyContent">' +
        `<p><b>Tarifa</b> $${tarifa1}</b></p>` + 
        `<p>Puestos libres: ${puestosLibres1} </p>` +
        "</div>" +
        "</div>";

        const contentString2 =
        '<div id="content">' +
        '<div id="siteNotice">' +
        "</div>" +
        '<h2 id="firstHeading" class="firstHeading">Parqueadero 2</h2>' +
        '<div id="bodyContent">' +
        `<p><b>Tarifa</b> $${tarifa2}</b></p>` + 
        `<p>Puestos libres: ${puestosLibres2} </p>` +
        "</div>" +
        "</div>";

        const infowindowParqueadero1 = new google.maps.InfoWindow({
            content: contentString1,
        });

        const infowindowParqueadero2 = new google.maps.InfoWindow({
            content: contentString2,
        });

        const markerPark1 = new google.maps.Marker({
            position: parqueadero1,
            map,
            title: "Parqueadero1",
            animation: google.maps.Animation.DROP,
        });
        markerPark1.addListener("click", () => {
            infowindowParqueadero1.open(map, markerPark1);

        
        });
        
        const markerPark2 = new google.maps.Marker({
            position: parqueadero2,
            map: map,
            title: "Parqueadero2",
            animation: google.maps.Animation.DROP,
        });
        markerPark2.addListener("click", () => {
            infowindowParqueadero2.open(map, markerPark2);
        });
        
        
        const infoWindow = new google.maps.InfoWindow({map: map});
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(function(position) {
            const pos = {
                lat: position.coords.latitude,
                lng: position.coords.longitude
            };
  
        infoWindow.setPosition(pos);
        infoWindow.setContent('Localizacion<b> encontrada</b>.');
        map.setCenter(pos);
        }, function() {
            handleLocationError(true, infoWindow, map.getCenter());
            });
        } else {
            // Browser doesn't support Geolocation
            handleLocationError(false, infoWindow, map.getCenter());
            }
            
    }



    function handleLocationError(browserHasGeolocation, infoWindow, pos) {
        infoWindow.setPosition(pos);
        infoWindow.setContent(browserHasGeolocation ?
                            'Error: Servicio de Geolocalizacion fallo' :
                            'Error: Su Navegador no soporta geolocalizacion.');
    }
    