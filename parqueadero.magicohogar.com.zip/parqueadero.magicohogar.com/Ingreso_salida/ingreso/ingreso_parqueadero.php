<html lang="en">
<head>
<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Ingreso parqueadero IoT</title>
</head>

<?php 
    include ("conexion.php");
    $mysqli = new mysqli($host, $user, $pw, $db);
    $parqueadero = $_GET['p'];

    /*Programa para validar estado*/
    $sql = "SELECT SUM(ocupacion) AS Ocupacion,COUNT(id) AS Total FROM `estados_puestos` WHERE parqueadero=$parqueadero";
    $result = $mysqli->query($sql);
    $row = $result->fetch_array();
    $numero_filas = $result->num_rows;

    mysqli_close($connection);   
?>


<body>    
    <div class="body"></div>
        
		<?php
            if (isset($parqueadero)){
    		if($row["Ocupacion"]==$row["Total"]){
        ?>
    			<div class="header">
    			    <div><span>Parqueadero <?php echo $parqueadero ?> </span></div>
    				<div><span>No hay puestos dispobibles.</span></div>
    			</div>
    	<?php
    		}
    		else{
    	?>
    	
    			<div class="header">
    			    <div><span>Parqueadero <?php echo $parqueadero ?> </span></div>
    				<div><span>Presione para ingresar.</span></div>
    				<br>
    			</div>
    			<br>
    			<form class="ingresar" action="clave_aleatoria.php?p=<?php echo $parqueadero ?>" method="post">
    				<!-- <input type="button" value="INGRESAR" id="btn-login" onclick="location.href='clave_aleatoria.php';">  -->
    				<input type="submit" value="INGRESAR" id="">
    			</form>
    	<?php
    		}
		}
		else{
		    http_response_code(400);
		?>
		    <div class="header">
				<div><span>Parqueadero no especificado.</span></div>
			</div>
		
		<?php
		}
		?>

		
        <div class="marca">
			<div>Parquedero <span>IoT</span></div>
		</div>
	<div id="alertaLogin"></div>
	<script>
	    const key = localStorage.getItem('keyParqueadero');
	    if (key !== 'Jparqueadero221587*j') {
	        window.location.href = "/404";
	    }
	</script>
</body>
</html>