<?php
   $str = "1234567890";
   $longitud=4;
   $clave= substr(str_shuffle($str),0,$longitud);
   $parqueadero = $_GET['p'];

   include ("conexion.php");
   $mysqli = new mysqli($host, $user, $pw, $db);

   //$sql = "SELECT id AS id_puesto, parqueadero AS Parqueadero, idPuesto AS PuestoParqueadero FROM estados_puestos WHERE ocupacion = 0 ORDER BY id ASC limit 1;";
   $sql = "SELECT id AS id_puesto, parqueadero AS Parqueadero, idPuesto AS PuestoParqueadero FROM estados_puestos WHERE (ocupacion=0) AND (parqueadero=$parqueadero) ORDER BY id ASC limit 1;";
   $result = $mysqli->query($sql);
   $row = $result->fetch_array();
   $id_puesto= $row["id_puesto"];
   $id_parqueadero= $row["Parqueadero"];
   $puestoparqueadero= $row["PuestoParqueadero"];
   $fecha= "now()";
   $sql = "UPDATE estados_puestos SET ocupacion=1 WHERE id=" . $id_puesto . " limit 1;";
   $result = $mysqli->query($sql);
   $sql = "INSERT INTO claves_confirmadas(clave,puesto) VALUES (" . $clave . ", " . $id_puesto . ");";
   
   $result = $mysqli->query($sql);
   $sql3 = "SELECT valor_tarifa FROM tarifas WHERE (id = ". $id_parqueadero. ")";
    $result3 = $mysqli->query($sql3);
    $row= $result3->fetch_array(MYSQLI_NUM);
    $tarifa= $row[0];
   

   $sql = "INSERT INTO pago(clave,puesto,Fecha_ingreso,Parqueadero,Tarifa,fecha) VALUES (" . $clave . ", " . $id_puesto . ", " . $fecha . "," . $parqueadero ."," . $tarifa ."," . $fecha .");";
   $result = $mysqli->query($sql);
    
    
?>

<html>
    <head>      
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="refresh" content="7;url=ingreso_parqueadero.php?p=<?php echo $parqueadero?>">
        <link rel="stylesheet" href="style.css">
        <title>Cod. Aleatorio IoT</title>
    </head>
    <body onload="aleatorio()">
        <div class="body"></div>
		<div class="header">
			<h1><span><?php echo $clave;?> </span></h1>
         <h2><span >Parqueadero disponible es:<?php echo $id_parqueadero;?> </span></h2>
         <h2><span >Puesto asignado:<?php echo $puestoparqueadero;?> </span></h2>
		</div>
  
        <div class="marca">
			<div>Parquedero<?php echo $tarifa;?> <span>IoT</span></div>
		</div>
    </body>
</html>
