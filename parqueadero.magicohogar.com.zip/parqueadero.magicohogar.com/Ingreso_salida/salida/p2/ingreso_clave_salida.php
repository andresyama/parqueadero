<html lang="en">
    <!--Ingreso clave parqueadero 2 -->
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="style.css">
        <title> Salida Parqueadero 1</title>
    </head>

    <body>
        <div class="body"></div>


        <form class ="confirmar" method=POST action="validar_salida.php">
            <div><h1> -- Parqueadero 2 -- <br> Por favor ingrese su clave:</h1></div>	 
            <input type="number" name="clave" value="" maxlength="4" placeholder="ej: 9808" required>  
			<input type="hidden" name="enviado" value="S1">  
		    <input type="submit" value="CONFIRMAR" name="confirmar">
        </form>
        
        <div class="marca">
            
			<div>Parquedero <span>IoT</span></div>
            
		</div>	 
		<script>
	    const key = localStorage.getItem('keyParqueadero');
	    if (key !== 'Jparqueadero221587*j') {
	        window.location.href = "/404";
	    }
	</script>
    </body>
</html>