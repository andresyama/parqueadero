<?php 
    include ("conexion.php");
    $mysqli = new mysqli($host, $user, $pw, $db);

    /*Programa para validar la clave de salida p2*/
    $clave = $_POST["clave"];
    $sql = "SELECT * from pago where clave=$clave";
    $result1 = $mysqli->query($sql);
    $row1 = $result1->fetch_array(MYSQLI_NUM);
    $fechaIngreso= $row1[1];
    $fechaActual = date("Y-m-d H:i:s");
    
    
    /*validar el tiempo entre el pago y la salida del p2*/
    $clave = $_POST["clave"];
    /*2021-09-24 04:54:52*/
    $sql = "SELECT TIMESTAMPDIFF(second,Fecha_pago,'$fechaActual') FROM `pago` WHERE clave=$clave";
    $result1 = $mysqli->query($sql);
    $row1 = $result1->fetch_array(MYSQLI_NUM);
    $Minutos= $row1[0];
    
    if($Minutos < 900 && $Minutos > 0)
    {
        $sql = "UPDATE claves_confirmadas SET pago=1 WHERE clave=$clave";
        $result = $mysqli->query($sql);
    }
    elseif($Minutos > 900)
    {
        $sql = "UPDATE claves_confirmadas SET pago=2 WHERE clave=$clave";
        $result = $mysqli->query($sql);
    }
    else
    {
        $sql = "UPDATE claves_confirmadas SET pago=0 WHERE clave=$clave";
        $result = $mysqli->query($sql);
    }
    
    $sql = "SELECT * from claves_confirmadas where clave=$clave";
    $result1 = $mysqli->query($sql);
    $row1 = $result1->fetch_array(MYSQLI_NUM);
    $numero_filas = $result1->num_rows;

    if ($numero_filas > 0)
    {
        $estado = $row1[3];
        if ($estado == 0)
        {
            $mensaje=0; 
        }
        elseif($estado == 1) 
        {
            $sql = "UPDATE estados_puestos SET ocupacion=0 WHERE id=" . $row1[2] . " limit 1;";
            $result = $mysqli->query($sql);
            $sql = "UPDATE pago SET Fecha_salida='$fechaActual' WHERE clave=$clave";
            $result = $mysqli->query($sql);
            $sql = "DELETE FROM claves_confirmadas WHERE claves_confirmadas.clave=" . $row1[1] . " limit 1;";
            $result = $mysqli->query($sql);
            $mensaje=1;
           }
        else
        {
            $mensaje=2;
        }
    }
    else
    {
        $mensaje=3;
    }
?>


<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="refresh" content="6; url=ingreso_clave_salida.php">
        <link rel="stylesheet" href="style2.css">
        <title> Ingreso clave de salida </title>
    </head>

    <body>
        <div class="body"></div>
        <div class="mensaje">
            <h1>
                <span class="exito">
                <?php 
                     
                    if ($mensaje == 1)
                        echo "¡Confirmación exitosa! <br> Fecha ingreso: $fechaIngreso <br> Fecha Salida: $fechaActual";
                ?>
                </span>

                <span class="error">
                <?php
                    if ($mensaje == 0)
                        echo "ERROR: No ha realizado el pago";
                    if ($mensaje == 2)
                        echo "ERROR: Excedió los 15 minutos, por favor realice el pago nuevamente";
                    if ($mensaje == 3)
                        echo "ERROR: La clave es incorrecta";
                ?>
                </span>
            </h1>
        </div>
        <div class="marca">
			<div>Parquedero <span>IoT</span></div>
		</div>	  
    </body>
</html>