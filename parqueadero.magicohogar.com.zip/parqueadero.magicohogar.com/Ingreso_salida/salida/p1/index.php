<?php
@ini_set('opcache.enable', '0');
include dirname(__FILE__).'/ingreso_clave_salida.php';
?>