<?php 
    include ("conexion.php");
    $mysqli = new mysqli($host, $user, $pw, $db);
    
?>
<html lang="en">
<head>

        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
        <link rel="stylesheet" href="../../localizacion/css/normalize.css">
        <link rel="stylesheet" href="../../localizacion/css/skeleton.css">
        <link rel="stylesheet" href="../../localizacion/css/custom.css">
        <link rel="stylesheet" href="style.css">
        <title> Interfaz Pago</title>
    </head>
    <body>
 
         
        
        <div class="marca">
            
			<div>Parquedero <span>IoT</span></div>
            
		</div>    
    <div class="titulo"><h1> Datos Servicio de Parqueo </h1></div>
    
        <form class ="contenedor" method=POST action="formulario">
        <div class= "titulo">
        <table>
        <thead>
        <tr>
          <th>Informacion</th>
          <th>Valores</th>
        </tr>
        
        </thead>
        <?php
            $clave = $_POST["clave"];
            $sql = "SELECT * from pago where clave=$clave";
            $result = $mysqli->query($sql);
            $mostrar = mysqli_fetch_array($result);
            $row1 = $result->fetch_array(MYSQLI_NUM);
        ?>
        <tbody>
            <tr>
                <td>Fecha de Ingreso </td>
                <td><?php echo $mostrar['Fecha_ingreso']?></td>
  
             </tr>
             <tr>
                <td>Fecha de Salida </td>
                <td><?php 
                $fechaActual = date('Y-m-d H:i:s');
                echo $fechaActual;?></td>
      
            </tr>
            <tr>
                <td>Tarifa </td>
                <td><?php echo $mostrar['Tarifa']?></td>
  
            </tr>
            <tr>
                <td>Tiempo estadia </td>
                <td><?php 
                    $fecha_ingreso=$mostrar['Fecha_ingreso'];
                    $date1 = new DateTime("$fecha_ingreso");
                    $date2 = new DateTime("now");
                    $diff = $date1->diff($date2);
                    echo $diff->days . ' Dias ' . $diff->h . ' Horas ' . $diff->i . ' Minutos ' ;
                    ?></td>
  
            </tr>
             <tr>
                <td>Puesto de parqueo </td>
                <td><?php echo $mostrar['puesto']?></td>
  
            </tr>
        </tbody>
        <tfoot>
            <tr>
                <th>Valor a pagar</th>
                <th><?php 
                    $tarifa = $mostrar['Tarifa'];
                    $NHdia = $diff-> days * 24;
                    $Nhoras= $diff -> h;
                    $NMin = $diff ->i;
                    if ($NMin >= 15){
                        $pagar = $NHdia*$tarifa + $tarifa*$Nhoras + $tarifa;
                    }else {$pagar = $NHdia*$tarifa + $tarifa*$Nhoras;}
                    
                    echo '$'. $pagar;
                ?></th>
            </tr>
        </tfoot>
        </table>
        </div>  
        
        </form>
        <form class ="confirmar" method=POST action="validar_salida.php">
        <div class= "boton">
        <input type="submit" value="Pagar" name="boton">
        <?php
            $sql = "UPDATE pago SET Fecha_salida=". $fechaActual . " WHERE clave=" . $row1[1] . " limit 1;";
        ?>
        </div>	
        </form>
        
    </body>

</html>