<?php


$host = "localhost";

$user = "magicoho_UserParqueadero";

$pw = "magicohoparqueadero";

$db = "magicoho_parqueadero";

$connection = mysqli_connect($host, $user, $pw, $db); 

?>