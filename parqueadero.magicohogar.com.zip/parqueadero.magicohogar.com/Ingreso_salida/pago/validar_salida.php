
<?php 
    include ("conexion.php");
    $mysqli = new mysqli($host, $user, $pw, $db);
    $clave = $_GET["clave"];

    $sql = "SELECT * FROM pago WHERE (clave='$clave') ";
    
    $result1 = $mysqli->query($sql);
    $row1 = $result1->fetch_array();
    if($row1==null){
     echo json_encode(array('success' =>-1));   
    }else {
    
    $fecha_ingreso = $row1["Fecha_ingreso"];
    $tarifa = $row1["Tarifa"];
    
    
    $fecha_actual = date("Y-m-d H:i:s");
    
    $date1 = strtotime($fecha_ingreso);
    $date2 = strtotime($fecha_actual);
    $hora_uso = round((($date2-$date1)/3600),2);
    $valor_pago=ceil($hora_uso*$tarifa);
    
    $sql = "UPDATE pago SET valor_cobrado=$valor_pago WHERE (clave='$clave')";
    $result = $mysqli->query($sql);
    
    $sql = "UPDATE claves_confirmadas SET pago=1 WHERE (clave='$clave')";
    $result = $mysqli->query($sql);
    
    $fechaActual = date("Y-m-d H:i:s");
    $sql = "UPDATE pago SET Fecha_pago='$fechaActual' WHERE clave=$clave";
    $result = $mysqli->query($sql);
            
    echo json_encode(array('success' =>1, data=>$valor_pago));
    }
?>


