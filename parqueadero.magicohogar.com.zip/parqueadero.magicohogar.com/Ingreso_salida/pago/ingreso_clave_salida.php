<html lang="en">
    <head>
        
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title>Parqueadero IoT</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
        <link rel="stylesheet" href="../../localizacion/css/normalize.css">
        <link rel="stylesheet" href="../../localizacion/css/skeleton.css">
        <link rel="stylesheet" href="../../localizacion/css/custom.css">
        <link rel="stylesheet" href="style.css">
        <title> Pagos</title>
    </head>

    <body>

        <header id="header" class="header">
    <div class="container">
        <div class="row">
            <div class="four columns">
                <img src="../../localizacion/img/logo1.png" id="logo">
            </div>           
        </div> 
    </div>
    
    </header>

    <div class="barra">
        <div class="container">
            <div class="row">
                    <div class="four columns icono icono1">
                        <p>Parking  <br>
                        en tiempo real</p>
                    </div>
                    <div class="four columns icono icono1">
                        <p>IoT aplicado <br>
                        Fácil acceso</p>
                    </div>
                    <div class="four columns icono icono3">
                        <p>Ahorra tiempo <br>
                        Conectate</p>
                    </div>
            </div>
            
        </div>

    </div>
    
    <div id="lista-cursos" class="container">
        <h1 id="encabezado" class="encabezado">Bienvenido</h1>
        <div class="row">
            <div class="col-md-6">
                <div class="card text-white" style="background: #1f1f93;">
                    <div class="card-body">
                        <h4 class="">Somos los mejores</h4>
                            <hr>
                            <p class="card-text">Gracias por escogernos, recuerda que aqui tendras el mejor servicio de parqueadero en la ciudad para mayor informacion comunicate con nosotros por cualquiera de nuestros medios digitales</p>
                            <button class="btn btn-light" id="contacto">
                                Contacto
                        </button>
                    </div>
                </div>
            </div>    
            <div class=" card col-md-6 ">
        <div class ="confirmar" method="POST" action="#" id="formulario">
            <div><h1> Por favor ingrese clave:</h1></div>	 
            <input type="number" name="clave" id="clave" value="" maxlength="4" placeholder="ej: 9808" required>  
			<input type="hidden" name="enviado" value="S1">  
		    <input type="submit" value="Pagar" name="confirmar" id="boton">
        </div>
            </div>
              
        </div>
    </div>
    <div class="row ">
        <div class="col d-flex align-content-center">
        
        </div>
        <div class="marca">
            
			<div>Parquedero <span>IoT</span></div>
            
		</div>	 
	</div>	
    </body>
    <script src="sweetalert2.all.min.js"></script>
    <script>
        
        
        const button = document.querySelector('#boton');
        button.addEventListener('click', ()=>{
           const clave = document.querySelector('#clave').value;
           console.log(clave)
           if(clave=='' || clave.length<3)
           {
               Swal.fire({
                  title: 'Error!',
                  text: 'Por favor ingrese una clave correcta',
                  icon: 'error',
                  confirmButtonText: 'ok'
                })
           } else {
               const URL =  `https://parqueadero.magicohogar.com/Ingreso_salida/pago/validar_salida.php?clave=${clave}`; 
               fetch(URL)
                .then(respuesta => respuesta.json())
                .then(({success, data}) => {
                    if(success==-1){
                       Swal.fire({
                          title: 'Error!',
                          text: 'Clave no registrada',
                          icon: 'error',
                          confirmButtonText: 'ok'
                        }) 
                    } else {
                        Swal.fire({
                          title: 'PAGO!',
                          text: `El valor a pagar es:$${parseFloat(data).toFixed(3)}`,
                          icon: 'info',
                          confirmButtonText: 'ok'
                          
                        })
                    }
                    
                });
           }
          //window.location.href = "https://parqueadero.magicohogar.com/Ingreso_salida/pago/programa_salida/interface_pago.php";
           
        });
    </script>
    
</html>