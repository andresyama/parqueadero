
<?php 
    include ("conexion.php");
    $mysqli = new mysqli($host, $user, $pw, $db);

    /*Programa para validar pago de la clave*/
    $clave = $_POST["clave"];
    $sql = "SELECT * from pago where clave=$clave";
    $result1 = $mysqli->query($sql);
    $row1 = $result1->fetch_array(MYSQLI_NUM);
    $numero_filas = $result1->num_rows;
    if ($numero_filas > 0)
    {
        $estado = $row1[4];
        if ($estado == 0)
        {
            $mensaje=0; 
        }
        elseif($estado == 1) 
        {
            $sql = "UPDATE estados_puestos SET ocupacion=0 WHERE id=" . $row1[3] . " limit 1;";
            $result = $mysqli->query($sql);
            $mensaje=1;

        }
        else
        {
            $mensaje=2;
        }
    }
    else
    {
        $mensaje=3;
    }
?>


<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <!--<meta http-equiv="refresh" content="4; url=ingreso_clave_salida.php">-->
        <link rel="stylesheet" href="style2.css">
        <title> Ingreso clave</title>
    </head>

    <body>
        <div class="body"></div>
        <div class="mensaje">
            <h1>
                <span class="exito">
                <?php 
                
                    if ($mensaje == 1)
                        echo "Pago exitoso. Gracias por preferirnos.";
                ?>
                </span>

                <span class="error">
                <?php
                    if ($mensaje == 0){
                        header("Location: interface_pago.php");
                        exit();
                        }
                    if ($mensaje == 2)
                        echo "ERROR: Código Excedió los 15 minutos ";
                        
                    if ($mensaje == 3){
                        echo "ERROR: La clave es incorrecta";
                        header("Refresh:4; url=ingreso_clave_salida.php");
                        }
                ?>
                </span>
            </h1>
        </div>
        <div class="marca">
			<div>Parquedero <span>IoT</span></div>
		</div>	  
    </body>
</html>