<?php
  include "conexion.php"; 
  date_default_timezone_set('America/Bogota_City');
  $fecha_actual= date("Y-m-d H:i:s");
  
  $conexion= mysqli_connect ('localHost', 'root','', 'magicoho_parqueadero');
  $fecha=$_POST['fecha_actual'];
  $consulta= "INSERT INTO claves_confirmadas(fecha_salida) VALUES ('$fecha')"
  $ejecutar=mysqli_query($conexion,$consulta);
?>