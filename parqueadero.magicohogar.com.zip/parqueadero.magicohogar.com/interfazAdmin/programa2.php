<?php
include "conexion.php";  // Conexi�n tiene la informaci�n sobre la conexi�n de la base de datos.

// LAs siguientes son l�neas de c�digo HTML simple, para crear una p�gina web
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 	Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
  <html>
    <head>
      <title> Datos Sensados Parqueadero IoT 
		  </title>
      <meta http-equiv="refresh" content="15" />
    </head>
    <body>
    
        <header width="80%" align=center cellpadding=5 bgcolor="#FFFFFF">
        <nav>
            <a href="programa2.php" class="activo">Programa2 Prox</a>
            <a href="programa4.php">Programa4 Prox</a>
            <a href="programa6.php">Programa6 Prox</a>
            <br>
            <br>
            <a href="/practica1/interfaces/programa2.php">Programa2 Temp</a>
            <a href="/practica1/interfaces/programa4.php">Programa4 Temp</a>
            <a href="/practica1/interfaces/programa6.php">Programa6 Temp</a>
            </nav>
        </div> 
    <br>
      <table width="80%" align=center cellpadding=5 border=1 bgcolor="#FFFFFF">
    	 <tr>
           <td valign="top" align=center width=80& colspan=6 bgcolor=#FFFFFF>
           <img src="imagen1.png" width=800 height=250>
         </td>
 	     </tr>
 	     <tr>
         <td valign="top" align=center width=80& colspan=6 bgcolor=#26a>
           <h1> <font color=white>Datos Sensados Parqueadero IoT</font></h1>
         </td>
 	     </tr>
    	 <tr>
         <td valign="top" align=center bgcolor="#E1E1E1">
            <b>#</b>
         </td>
         <td valign="top" align=center bgcolor="#E1E1E1">
            <b>Id de la Tarjeta</b>
         </td>
         <td valign="top" align=center bgcolor="#E1E1E1">
            <b>Fecha</b>
         </td>
         <td valign="top" align=center bgcolor="#E1E1E1">
            <b>Hora</b>
         </td>
         <td valign="top" align=center bgcolor="#E1E1E1">
            <b>Distancia</b>
         </td>
         <td valign="top" align=center bgcolor="#E1E1E1">
            <b>Estado</b>
         </td>
 	     </tr>
<?php
// la siguiente linea almacena en una variable denominada sql1, la consulta en lenguaje SQL que quiero realizar a la base de datos. Se consultan los datos de la tarjeta 1, porque en la tabla puede haber datos de diferentes tarjetas.
$sql1 = "SELECT * from datos_medidos_parqueadero order by id DESC LIMIT 12"; // Aqu� se ingresa el valor recibido a la base de datos.
// la siguiente l�nea ejecuta la consulta guardada en la variable sql, con ayuda del objeto de conexi�n a la base de datos mysqli
//$result1 = $mysqli->query($sql1);
$result1 = mysqli_query($connection, $sql1);
// la siguiente linea es el inicio de un ciclo while, que se ejecuta siempre que la respuesta a la consulta de la base de datos
// tenga alg�n registro resultante. Como la consulta arroja 5 resultados, los �ltimos que tenga la tabla, se ejecutar� 5 veces el siguiente ciclo while.
// el resultado de cada registro de la tabla, se almacena en el arreglo row, row[0] tiene el dato del 1er campo de la tabla, row[1] tiene el dato del 2o campo de la tabla, as� sucesivamente
$contador = 0;
while($row1 = $result1->fetch_array(MYSQLI_NUM))
{
 $state = $row1[2];
 $dist = $row1[3];
 if ($dist ==1){
   $est='Ocupado';
 } else{
   $est='Libre';
 }
 $fecha = $row1[4];
 $hora = $row1[5];
 $ID_TARJ = $row1[1];
 $contador++;
?>
    	 <tr>
         <td valign="top" align=center>
           <?php echo $contador; ?> 
         </td>
         <td valign="top" align=center>
           <?php echo $ID_TARJ; ?> 
         </td>
         <td valign="top" align=center>
           <?php echo $fecha; ?> 
         </td>
         <td valign="top" align=center>
           <?php echo $hora; ?> 
         </td>
         <td valign="top" align=center>
           <?php echo $state." cm"; ?> 
         </td>
         <td valign="top" align=center>
           <?php echo $est.""; ?> 
         </td>
 	     </tr>
<?php
}
?>
     </body>
   </html>