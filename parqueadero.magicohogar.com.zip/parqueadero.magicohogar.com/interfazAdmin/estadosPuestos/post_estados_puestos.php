<?php
$data = json_decode(file_get_contents('php://input'), true);
include "conexion.php";

$nuevosEstados = $data['estados'];
$idsEstadoPuestos = array_keys($nuevosEstados);
foreach ($idsEstadoPuestos as $key){
  //echo $key . " => " . $nuevosEstados[$key];
  $sql = "UPDATE estados_puestos SET estado = " . $nuevosEstados[$key] . " WHERE idEstadoPuesto = " . $key; 
  $result = mysqli_query($connection, $sql);
}
echo $result;
//include "get_estados_puestos.php"
?>