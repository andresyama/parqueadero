let estados = {};
let editando = false;
let switches;
let btnGuardar = document.getElementById("btnGuardar");


fetch('https://parqueadero.magicohogar.com/interfazAdmin/estadosPuestos/get_estado_puestos.php')
.then(response => response.json())
.then(data => {
  console.log(data);
  let string = '';
  data.map(function(item) {
    let estado = Number(item.estado) ? 'checked' : ' ';
    let ocupacion, bg;
    if(Number(item.ocupacion)){
      ocupacion = 'Ocupado';
      bg = 'bg-danger';
    }
    else {
      ocupacion = 'Disponible';
      bg = 'bg-success';
    }
    
    string += '' +
    '<tr>' +
    '<th scope="row">'+ item.idEstadoPuesto +'</th>' +
    '<td>'+ item.parqueadero +'</td>' +
    '<td>'+ item.ID_TARJ +'</td>' +
    '<td>'+ item.idPuesto +'</td>';

      estados[item.idEstadoPuesto] = Number(item.estado);
    let estadoStr = '<td>' +
    '<div class="form-check form-switch">' +
      '<input class="form-check-input" type="checkbox" id="'+item.idEstadoPuesto+'" '+estado+' />' +
    '</div>'+
    '</td>';
    string += estadoStr + 
    '<td class="text-white '+bg+'">'+ ocupacion +'</td>' +
    '<td>'+ item.fecha +'</td>' +
    '<td>'+ item.hora_inicial +'</td>' +
    '<td>'+ item.hora_final +'</td>' +
    '</tr>';
  });
  let listaPuestos = document.getElementById("tabla-puestos");
  listaPuestos.innerHTML = string;
  //console.log(estados);
  switches = document.getElementsByClassName("form-check-input");
  desactivarSwitches();
  eventosSwitches();
});

function editandoHandler(e){
  let btnEditar = document.getElementById("btnEditar");
  editando = !editando;
  if (editando){
    btnEditar.textContent = 'Cancelar';
    btnEditar.classList.remove('btn-light');
    btnEditar.classList.add('btn-danger');
  }
  else{
    btnEditar.textContent = 'Editar';
    btnEditar.classList.remove('btn-danger');
    btnEditar.classList.add('btn-light');
  }
  desactivarSwitches();
}

function desactivarSwitches(){
  btnGuardar.disabled = !editando;    
  for (aSwitch of switches){
    aSwitch.disabled = !editando;
  }
}

function eventosSwitches(){
  for (aSwitch of switches){
    aSwitch.addEventListener("click", actualizarEstados);
  }
}

function actualizarEstados(e){
  estados[e.target.id] = estados[e.target.id] ? 0 : 1; 
  console.log(JSON.stringify({estados: estados}));
}

function guardarEstados(){

  fetch("https://parqueadero.magicohogar.com/interfazAdmin/estadosPuestos/post_estados_puestos.php", {
    method: 'POST',
    //mode: 'cors',
    headers: {
      'Content-Type': 'application/json'
    },
    redirect: 'follow',
    body: JSON.stringify({estados: estados})
  })
  .then(response => {
    location.reload();
  });
  
  //console.log(await response.json());
}

btnGuardar.addEventListener("click", guardarEstados);
document.getElementById("btnEditar").addEventListener("click", editandoHandler);
