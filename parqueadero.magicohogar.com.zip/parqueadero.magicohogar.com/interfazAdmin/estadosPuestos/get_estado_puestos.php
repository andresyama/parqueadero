<?php
  include "conexion.php";
  $sql = "SELECT * from estados_puestos"; 
  $result = mysqli_query($connection, $sql);

  $columnsResult = $result->fetch_fields();
  $columns = array();
  foreach($columnsResult as $element){
    array_push($columns, $element->name);
  }

  $i = 0;
  $data = array();
  while($row = mysqli_fetch_array($result)){
    // echo ($row[0] . ' ' . $row[1] . ' ' . $row[2] . ' ' . $row[3]);
    // echo ("<br>");
    foreach($columns as $column){
      $data[$i][$column] = $row[$column];
    }    
    $i++;
  }

  echo json_encode($data);
?>