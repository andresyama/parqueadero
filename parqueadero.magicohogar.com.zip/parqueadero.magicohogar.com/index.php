<html lang="es">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KyZXEAg3QhqLMpG8r+8fhAXLRk2vvoC2f3B09zVXn8CA5QIVfZOJ3BCsw2P0p/We" crossorigin="anonymous">
    <title>Parqueadero Inteligente Unicauca 2021</title>
    
</head>
<body>
    <div class="body"></div>
		<div class="grad"></div>
		<div class="header">
			<div>Parquedero<span>IoT</span></div>
		</div>
		<br>
		<form class="login" action="" method="post">
				<input type="text" placeholder="username" name="user" autocomplete="off" required="" id="txt-usuario"><br>
				<input type="password" placeholder="password" name="password" required="" id="txt-password"><br>
				<input type="button" value="Login" id="btn-login">
		</form>
	<script src="codigo.js"></script>
	
</body>
</html>