<?php
  if (isset($_GET['periodo'])){
    switch ($_GET['periodo']){
      case 'anual':
        include("./yearlyData.php");
      break;
      case 'mensual':
        include("./monthlyData.php");
      break;
      case 'diario':
        include("./dailyData.php");
      break;
      default:
        badReqResponse();
    }
  }
  else {
    badReqResponse();
  }

  function badReqResponse(){
    http_response_code(400);
    $data = [
      "error" => "400 - Bad Request",
      "msg" => "Params has not been set or they're incorrect"
    ];
    header('Content-type: application/json');
    echo json_encode($data);
  }

?>