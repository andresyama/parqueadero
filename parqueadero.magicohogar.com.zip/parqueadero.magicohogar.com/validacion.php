<?php
    include('conexion.php');

    if(isset($_POST['user']) && !empty($_POST['user'] && $_POST['password']) && !empty($_POST['password'])){
       $user = $_POST['user']; 
       $password = $_POST['password']; 
       $query = "SELECT idUsuario FROM usuarios WHERE (user = '$user' && password = '$password')";
       $result = mysqli_query($connection, $query);
      

       if(mysqli_num_rows($result) > 0){
           $respuesta = $result->fetch_array(MYSQLI_NUM);
           $idUsuario = $respuesta[0];
           $query2 = "SELECT activo FROM usuarios WHERE (idUsuario = $idUsuario)";
           $result2 = mysqli_query($connection, $query2);
           $activo=$respuesta = $result2->fetch_array(MYSQLI_NUM);
           if ($activo[0] == 1){
                echo json_encode(array('success' => 1, 'idUsuario'=>$idUsuario));
           }
           else {
               echo json_encode(array('success' => 0));
           }
       } else{
           echo json_encode(array('success' => -1));
       }
    } 

    ?>
    
	
