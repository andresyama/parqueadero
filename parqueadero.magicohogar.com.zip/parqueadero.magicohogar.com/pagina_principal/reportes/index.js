let myChart;

document.getElementById('periodo').addEventListener('change', function(e){
  getData(e.target.value);
});


function getData(periodo){

  // borrador
  if (myChart) {
    myChart.destroy();
  }  
  let dataDef;
  fetch(`./reportData.php?periodo=${periodo}`).then(function(response) {
    response.json().then(data => {
      dataDef = data;
      console.log(dataDef);
      labels = Object.keys(data);

      let dataP1 = [];
      let dataP2 = [];
      for (const key in data) {
        dataP1.push(data[key]['1'] ? data[key]['1']['cobrado'] * 1000 : 0);
        dataP2.push(data[key]['2'] ? data[key]['2']['cobrado'] * 1000 : 0);
      }
      

      //  Construir grafico
      var ctx = document.getElementById('chart');
      myChart = new Chart(ctx, {
      type: 'bar',
      data: {
          labels: labels,
          datasets: [{
              label: 'Parqueadero 1',
              data: dataP1,
              backgroundColor: 'rgba(255, 99, 132, 0.2)',
              borderColor: 'rgba(255, 99, 132, 1)',
              borderWidth: 1
          },
          {
              label: 'Parqueadero 2',
              data: dataP2,
              backgroundColor: 'rgba(54, 162, 235, 0.2)',
              borderColor: 'rgba(54, 162, 235, 1)',
              borderWidth: 1
          },
          ]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          scales: {
            x: {
              title:{
                display: true,
                // TOOO: Cambiar este titulo del eje X
                
              }
            },
            y: {
              title: {
                display: true,
                text: "Total Cobrado"
              },
              beginAtZero: true
            }
          },
          plugins: {
            title: {
              display: true,
              text: 'Reporte'
            },
            tooltip: {
              callbacks: {
                footer: (tooltipItems) => {
                  let label = tooltipItems[0].label;
                  let parqueadero = tooltipItems[0].datasetIndex + 1;
                  return `Vehiculos ingresados: ${dataDef[label][parqueadero]['vehiclesNum']}`;
                },
              }
            }
          }
        }
      });
    })
  }); 

}
