<?php
$data = [];
include("./conexion.php");

$consulta = "SELECT DAY(Fecha_ingreso) AS dia, Parqueadero, COUNT('dia') AS vehiclesNum, SUM(valor_cobrado) AS cobrado
FROM pago WHERE YEAR(Fecha_ingreso)=YEAR(now()) AND MONTH(Fecha_ingreso)=MONTH(now()) 
GROUP BY DAY(Fecha_ingreso),Parqueadero;";

$resultado = mysqli_query($conexion, $consulta);
while ($row = mysqli_fetch_assoc($resultado)) {
  $data[ $row['dia'] ][ $row['Parqueadero'] ] = [
    "vehiclesNum" => $row['vehiclesNum'],
    "cobrado" =>$row['cobrado']
  ];
}

header('Content-type: application/json');
echo json_encode($data);
?>