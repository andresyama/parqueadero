<?php
$data = [];
include("./conexion.php");

$consulta = "SELECT YEAR(Fecha_ingreso) AS anio, Parqueadero, count('anio') AS vehiclesNum, SUM(valor_cobrado) AS cobrado
  FROM pago GROUP BY YEAR(Fecha_ingreso),Parqueadero;";
$resultado = mysqli_query($conexion, $consulta);
while ($row = mysqli_fetch_assoc($resultado)) {
  $data[ $row['anio'] ][ $row['Parqueadero'] ] = [
    "vehiclesNum" => $row['vehiclesNum'],
    "cobrado" =>$row['cobrado']
  ];
}

header('Content-type: application/json');
echo json_encode($data);
?>