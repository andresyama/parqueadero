<?php
include("./conexion.php");
$consulta = "SELECT DAY(Fecha_ingreso) as dia, count(*) as vehiclesNum, SUM(valor_cobrado) as cobrado
  from pago
  group by DAY(Fecha_ingreso);";
$resultado = mysqli_query($conexion, $consulta);
$data = [];
while ($row = mysqli_fetch_assoc($resultado)) {
  $rowData = [];
  $data[$row['dia']] = [$row['vehiclesNum'], $row['cobrado'] ];
}  
header('Content-type: application/json');
echo json_encode($data);
?>