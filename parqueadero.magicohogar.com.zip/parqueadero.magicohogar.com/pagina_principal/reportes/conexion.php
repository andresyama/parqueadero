<?php


$host = "localhost";

$user = "magicoho_UserParqueadero";

$pw = "magicohoparqueadero";

$db = "magicoho_parqueadero";

$conexion = mysqli_connect($host, $user, $pw, $db); 
?>