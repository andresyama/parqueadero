<?php
$data = [];
include("./conexion.php");

$consulta = "SELECT MONTH(Fecha_ingreso) AS mes, Parqueadero, COUNT('mes') AS vehiclesNum, SUM(valor_cobrado) AS cobrado
FROM pago WHERE YEAR(Fecha_ingreso)=YEAR(now()) GROUP BY MONTH(Fecha_ingreso),Parqueadero;";
$resultado = mysqli_query($conexion, $consulta);
while ($row = mysqli_fetch_assoc($resultado)) {
  $mes = parsearMes($row['mes']);
  $data[ $mes ][ $row['Parqueadero'] ] = [
    "vehiclesNum" => $row['vehiclesNum'],
    "cobrado" =>$row['cobrado']
  ];
}
header('Content-type: application/json');
echo json_encode($data);

function parsearMes($mesNum){
  switch ($mesNum){
    case 1:
      return 'Enero';
    case 2:
      return 'Febrero';
    case 3:
      return 'Marzo';
    case 4:
      return 'Abril';
    case 5:
      return 'Mayo';
    case 6:
      return 'Junio';
    case 7:
      return 'Julio';
    case 8:
      return 'Agosto';
    case 9:
      return 'Septiembre';
    case 10:
      return 'Octubre';
    case 11:
      return 'Noviembre';
    case 12:
      return 'Diciembre';
  }
}
?>