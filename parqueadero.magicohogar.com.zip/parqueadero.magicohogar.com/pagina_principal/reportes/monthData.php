<?php
include("./conexion.php");
$consulta = "SELECT MONTH(Fecha_ingreso) as mes, count(*) as vehiclesNum, SUM(valor_cobrado) as cobrado
  from pago
  group by MONTH(Fecha_ingreso);";
$resultado = mysqli_query($conexion, $consulta);
$data = [];
while ($row = mysqli_fetch_assoc($resultado)) {
  $rowData = [];
  $data[$row['mes']] = [$row['vehiclesNum'], $row['cobrado'] ];
}  
header('Content-type: application/json');
echo json_encode($data);
?>