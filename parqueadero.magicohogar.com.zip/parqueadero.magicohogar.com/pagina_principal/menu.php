<?php

$idUsuarios = $_GET["idUsuario"];
?>
<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<title>Menu</title>
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
	<link rel="stylesheet" href="menu.css">
	<link rel="stylesheet" href="fonts.css">
	<script src="http://code.jquery.com/jquery-latest.js"></script>
	<script src="menu.js"></script>
</head>                            
	<body>	
       <header>
		<div class="menu">
			<a href="#" class="bt-menu"><span class="icon-menu"></span>Menu</a>
		</div>
 
		<nav class= "subp">
			<ul>
				<li>
				    <a href="pagina_principal.php?idUsuario=<?php echo $idUsuarios ?>" target="_parent"><span class="icon-home"></span>Inicio</a>
				</li>
				<li >
					<a href="gestion_usuarios/gestion_usuarios.php?idUsuario=<?php echo $idUsuarios ?>" target="_parent"><span class="icon-user"></span>Gestion de Administradores</a>
				</li>
				<li>
				    <a href="estado_puestos/tabla_estado_puesto.php?idUsuario=<?php echo $idUsuarios ?>" target="_parent"><span class="icon-map2"></span>Mapa puestos</a>
				</li>
				<li>
				    <a href="des_act_puestos/des_act.php?idUsuario=<?php echo $idUsuarios ?>" target="_parent"><span class="icon-equalizer2"></span>Cambiar Disponibilidad</a>
				</li>
				<li>
					<a href="tarifas/window_tarifa.php?idUsuario=<?php echo $idUsuarios ?>" target="_parent"><span class="icon-coin-dollar"></span>Tarifas</a>	
				</li>

				<li>
					<a href="reportes/index.html?idUsuario=<?php echo $idUsuarios ?>" target="_parent"><span class="icon-stats-dots"></span>Reportes</a>	
				</li>
				
				<li>
				    <div id="cerrar">
				    <a href="../index.php" target="_parent"><span class="icon-exit" ></span>Cerrar sesion</a>
				    </div>
				</li>
			</ul>
		</nav>
	</header>  
	</body>

</html>




