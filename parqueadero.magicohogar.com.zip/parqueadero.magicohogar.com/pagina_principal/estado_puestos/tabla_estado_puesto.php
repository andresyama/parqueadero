<?php
include "../../conexion.php";
$mysqli = new mysqli($host, $user, $pw, $db);
$idUsuarios = $_GET["idUsuario"];
?>

  <html>
    <head>
      <title> Estado de los puestos
		  </title>
      <meta http-equiv="refresh" content="30" />
      <link rel="stylesheet" type="text/css" href="tabla_estado_puesto.css" th:href="@{tabla_estado_puesto.css}"> 
    </head>
    <body class="tabla_estado_puesto">
        <iframe src="../menu.php?idUsuario=<?php echo $idUsuarios?>" class="menus"></iframe>
      <table cellpadding=5 border=1 class="tabla">
         <td  align=center colspan=5  bgcolor="#CFE2FF">
           <h1> <font color=white>INFORMACION DE PUESTOS</font></h1>
         </td>
 	     </tr>
    	 <tr>
         <td align=center bgcolor="#E1E1E1">
            <b>#</b>
         </td>
         <td align=center bgcolor="#E1E1E1">
            <b>Parqueadero</b>
         </td>
         <td align=center bgcolor="#E1E1E1">
            <b>Numero de puesto</b>
         </td>
         <td align=center bgcolor="#E1E1E1">
            <b>Estado</b>
         </td>
         <td align=center bgcolor="#E1E1E1">
            <b>Ocupacion</b>
         </td>
 	     </tr>
<?php
$sql1 = "SELECT * from estados_puestos order by id LIMIT 8";
$result1 = $mysqli->query($sql1);
$contador = 0;
while($row1 = $result1->fetch_array(MYSQLI_NUM))
{
 $parqueadero = $row1[1];
 $num_puestos = $row1[3];
 $estado = $row1[4];
 $ocupacion = $row1[5];
 $contador++;
?>
    	 <tr>
         <td align=center bgcolor="#E1E1E1">
           <?php echo $contador; ?> 
         </td>
         <td align=center bgcolor="#E1E1E1">
           <?php echo $parqueadero; ?> 
         </td>
         <td align=center bgcolor="#E1E1E1">
           <?php echo $num_puestos; ?> 
         </td>
         <td align=center bgcolor="#E1E1E1" class='ocupaciones'>
           <?php 
           if($estado==1){
                echo "Activo";
              }
              else if($estado == 0){
                echo "No activo";
              }
           ; ?> 
         </td>
         <td align=center bgcolor="#E1E1E1" class='estados'>
           <?php 
            if($ocupacion==0){
                echo "libre";
              }
              else if($ocupacion == 1){
                echo "ocupado";
              }
           ; ?>
         </td>
 	     </tr>
<?php
}
?>
     </body>
     <canvas class='figuraParqueadero' id="campo" width="500" height="500"></canvas>
     <script src='app.js'></script>
   </html>