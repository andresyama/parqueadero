const puestos = document.querySelectorAll('.ocupaciones');
const vectorEstados = [];
const ocupaciones = document.querySelectorAll('.estados');
const vectorOcupaciones = [];


const vp = document.getElementById("campo");
const papel = vp.getContext("2d");
   
const fondo = {
    url: "tile.png",
    cargaOk: false
};

const ocupacionImg = {
    url: "car.png",
    cargaOk: false
};

const estadoImg = {
    url: "sin-carro.png",
    cargaOk: false
};

fondo.imagen = new Image();
fondo.imagen.src = fondo.url;
fondo.imagen.addEventListener("load",cargarFondo);

ocupacionImg.imagen=new Image();
ocupacionImg.imagen.src = ocupacionImg.url;
ocupacionImg.imagen.addEventListener("load", cargarOcupacionImg);

estadoImg.imagen = new Image();
estadoImg.imagen.src = estadoImg.url;
estadoImg.imagen.addEventListener("load", cargarEstadoImg);

ocupaciones.forEach(element => {
    vectorOcupaciones.push(element.innerText);
});

puestos.forEach(element => {
    vectorEstados.push(element.innerText);
});

console.log(vectorEstados);
console.log(vectorOcupaciones);

//FUNCIONES 

function cargarFondo()
{
    fondo.cargaOk = true;
    dibujar();
}

function cargarOcupacionImg()
{
    ocupacionImg.cargaOk = true;
    dibujar();
}

function cargarEstadoImg()
{
 
    estadoImg.cargaOk = true;
    dibujar();
}

function dibujar()
{ 
     
    if (fondo.cargaOk)
    {
        papel.drawImage(fondo.imagen, 0, 0);
    }
    if (ocupacionImg.cargaOk)
    {
        x = 20;
        y = 160;
        for (let i = 0; i < 4; i++) {
            
            if (vectorOcupaciones[i]=='ocupado' && vectorEstados[i] == 'Activo')
            {   
                papel.drawImage(ocupacionImg.imagen, x, y);
            }
            x = x+128;
        }

        x = 20;
        y = 395;
        for (let i = 4; i < vectorOcupaciones.length; i++) {
          
            if (vectorOcupaciones[i]=='ocupado' && vectorEstados[i] == 'Activo')
            {
                papel.drawImage(ocupacionImg.imagen, x, y);
                
            }
            x = x+128;
        }
    }

    if (estadoImg.cargaOk) {
        x = 20;
        y = 145;
        for (let i = 0; i < vectorEstados.length-4; i++) {
            
            if (vectorEstados[i] == 'No activo')
            {
                papel.drawImage(estadoImg.imagen, x, y);
            }
            x = x+128;
        }

        x = 20;
        y = 394;
        for (let i = 4; i < vectorOcupaciones.length; i++) {
            
            if (vectorEstados[i] == 'No activo')
            {
                papel.drawImage(estadoImg.imagen, x, y);
            }
            x = x+128;
        }
    }
}