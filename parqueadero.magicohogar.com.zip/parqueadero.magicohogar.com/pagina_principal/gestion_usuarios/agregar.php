<?php
include "../../conexion.php";
$mysqli = new mysqli($host, $user, $pw, $db);
$usuario=$_POST["usuario"];
$contrasena=$_POST["contrasena"];
$nombre= $_POST["nombre"];
$activo=isset($_POST["activo"]);
$direccion=$_POST["direccion"];
$telefono=$_POST["telefono"];
$correo=$_POST["correo"];
$id = $_POST["id"];
if ($activo!=1)
{$activo=0;}

$sql1 = "INSERT INTO usuarios (user, password, nombre, activo, direccion, telefono, correo) VALUES('$usuario', '$contrasena', '$nombre', '$activo', '$direccion', '$telefono', '$correo')";  

$verificar= $mysqli->query("SELECT * FROM usuarios where user='$usuario'");
if(mysqli_num_rows($verificar)>0)
{
    echo '<script>
    alert("El usuario ya existe");
    window.location.replace("agregar_usuario.php");
    </script>'; 
    exit;
}

$result1 = $mysqli->query($sql1);
if(!$result1)
{
    echo '<script>
    alert("Error al registrar usuario");
    window.location.replace("agregar_usuario.php");
    </script>';
}else
{
    echo '<script>
    alert("El usuario se ha registrado exitosamente");
    window.location.replace("agregar_usuario.php");
    </script>';
}

?>




