<?php
include "../../conexion.php";
$idUsuarios = $_GET["idUsuario"];
$id = $_POST["id"];
?>
 
<!DOCTYPE html>
  <html lang='es'>
    <head>
        <meta charset="UTF-8">
        <link rel="stylesheet" type="text/css" href="modificar_usuario.css" th:href="@{modificar_usuario.css}">  
                            
    </head>
        <body class="modificar_usuario">


            <table class="tabla" align=center> 
            <tr> 
            <td valign="top" align=center colspan=6>
                <h1> <font color=white>Modificar usuario</font></h1>
            </td>
 	        </tr>
 	        
<?php
 if ((isset($_POST["enviado"])))  
   {
   $enviado = $_POST["enviado"];
   if ($enviado == "S1")
    {
          $nombre = $_POST["nombre"];  
          $correo = $_POST["correo"];
          $telefono = $_POST["telefono"];
          $direccion = $_POST["direccion"];
          $activo = isset($_POST["activo"]);
          if ($activo!=1)
          {$activo=0;} 
          $id = $_POST["id"];
          $mysqli = new mysqli($host, $user, $pw, $db); 
          $sql1 = "UPDATE usuarios set nombre='$nombre'  where idUsuario=$id";  
          $result1 = $mysqli->query($sql1);
          
          $sql2 = "UPDATE usuarios set activo='$activo' where idUsuario=$id"; 
          $result2 = $mysqli->query($sql2);
          $sql3 = "UPDATE usuarios set direccion='$direccion' where idUsuario=$id"; 
          $result3 = $mysqli->query($sql3);
          $sql4 = "UPDATE usuarios set telefono='$telefono' where idUsuario=$id"; 
          $result4 = $mysqli->query($sql4);
          $sql5 = "UPDATE usuarios set correo='$correo' where idUsuario=$id"; 
          $result5 = $mysqli->query($sql5);

          if (($result1 == 1)&&($result2 == 1)&&($result3 == 1)&&($result4 == 1)&&($result5 == 1))
          {

            header("Location:gestion_usuarios.php?idUsuario=$idUsuarios&variable=S1");
            
          }
          else
             {
                header("Location:gestion_usuarios.php?idUsuario=$idUsuarios&variable=S2");
          }

         

    } // FIN DEL IF, si ya se han recibido los datos del formulario
   }  // FIN DEL IF, si la variable enviado existe, que es cuando ya se env�o el formulario
  
// AQUI CONSULTA LOS VALORES ACTUALES DE LAS TARIFAS, PARA PRESENTARLOS EN EL FORMULARIO
// CONSULTA nombre
$mysqli = new mysqli($host, $user, $pw, $db); 
$sql1 = "SELECT * from usuarios where idUsuario=$id"; 
$result1 = $mysqli->query($sql1);
$row1 = $result1->fetch_array(MYSQLI_NUM);
$nombre = $row1[3];   

// CONSULTA ESTADO
$mysqli = new mysqli($host, $user, $pw, $db); 
$sql2 = "SELECT * from usuarios where idUsuario=$id"; 
$result2 = $mysqli->query($sql2);
$row2 = $result2->fetch_array(MYSQLI_NUM);
$activo = $row2[4]; 

// CONSULTA direccion
$mysqli = new mysqli($host, $user, $pw, $db); 
$sql3 = "SELECT * from usuarios where idUsuario=$id"; 
$result3 = $mysqli->query($sql3);
$row3 = $result3->fetch_array(MYSQLI_NUM);
$direccion = $row3[5];  
// CONSULTA telefono
$mysqli = new mysqli($host, $user, $pw, $db); 
$sql4 = "SELECT * from usuarios where idUsuario=$id"; 
$result4 = $mysqli->query($sql4);
$row4 = $result4->fetch_array(MYSQLI_NUM);
$telefono = $row4[6];  
// CONSULTA correo
$mysqli = new mysqli($host, $user, $pw, $db); 
$sql5 = "SELECT * from usuarios where idUsuario=$id"; 
$result5 = $mysqli->query($sql5);
$row5 = $result5->fetch_array(MYSQLI_NUM);
$correo = $row5[7];  

?>
 	        
 	        <form method=POST action="modificar_usuario.php?idUsuario=<?php echo $idUsuarios?>">
 	        <tr>	
      		    <td bgcolor="#CCEECC" align=center> 
			   	  <font FACE="arial" SIZE=2 color="#000044"> <b>Nombre: </b></font>  
				  </td>	
				  <td bgcolor="#EEEEEE" align=center> 
				    <input step="any" name="nombre" value="<?php echo $nombre; ?>" required>  
                    </td>	
	                 </tr>
	                 
	                 <tr>	
      		    <td bgcolor="#CCEECC" align=center> 
			   	  <font FACE="arial" SIZE=2 color="#000044"> <b>Direccion: </b></font>  
				  </td>	
				  <td bgcolor="#EEEEEE" align=center> 
				    <input step="any" name="direccion" value="<?php echo $direccion; ?>" required>  
                    </td>	
	                 </tr>
	                 
	                 <tr>	
      		    <td bgcolor="#CCEECC" align=center> 
			   	  <font FACE="arial" SIZE=2 color="#000044"> <b>Telefono: </b></font>  
				  </td>	
				  <td bgcolor="#EEEEEE" align=center> 
				    <input step="any" name="telefono" value="<?php echo $telefono; ?>" required>  
                    </td>	
	                 </tr>
	                 
	                 <tr>	
      		    <td bgcolor="#CCEECC" align=center> 
			   	  <font FACE="arial" SIZE=2 color="#000044"> <b>Correo: </b></font>  
				  </td>	
				  <td bgcolor="#EEEEEE" align=center> 
				    <input step="any" name="correo" value="<?php echo $correo; ?>" required>  
                    </td>	
	                 </tr>
	                 
 	               <tr>	
      		<td bgcolor="#CCEECC" align=center> 
			   	  <font FACE="arial" SIZE=2 color="#000044" > <b>Estado: </b></font>  
				  </td>	
				 <td align=center bgcolor="#E1E1E1">
            <?php             
            if($activo==1){
                $e="checked";               
              }
              else if($activo != 1){
                $e="uchecked";
              }
            ;?>
            
            <label class= "switch">
            <input type="checkbox" name="activo" <?php echo $e ?>>
            <span class= "slider"></span>
            </label>
            
          </td>    
	     </tr>
       <tr>	
				  <td bgcolor="#EEEEEE" align=center colspan=2> 
				    <input type="hidden" name="enviado" value="S1"> 
				    <input type="hidden" name="id" value =<?php echo $id;?>>
				    <input type="submit" class="btn_form" value="Modificar" name="Actualizar">  
          </td>	
	     </tr>
      </form>	
            </table>    
          
      <iframe src="../menu.php?idUsuario=<?php echo $idUsuarios?>" class="menus"></iframe>
            
    
        </body>
       
   </html>