<?php
include "../../conexion.php";
$mysqli = new mysqli($host, $user, $pw, $db);
$idUsuarios = $_GET["idUsuario"];
$id = $_POST["id"];
?>
 
<!DOCTYPE html>
  <html lang='es'>
    <head>
        <meta charset="UTF-8">
        <link rel="stylesheet" type="text/css" href="agregar_usuario.css" th:href="@{agregar_usuario.css}">  
                            
    </head>
        <body class="agregar_usuario">

            <table class="tabla" align=center> 
            <tr> 
            <td valign="top" align=center colspan=6>
                <h1> <font color=white>Agregar usuario</font></h1>
            </td>
 	        </tr>
 	        
 	        
 	        
 	        
 	        <?php
 if ((isset($_POST["enviado"])))  
   {
   $enviado = $_POST["enviado"];
   if ($enviado == "S1")
    {
        $usuario=$_POST["usuario"];
        $contrasena=$_POST["contrasena"];
        $nombre= $_POST["nombre"];
        $activo=isset($_POST["activo"]);
        $direccion=$_POST["direccion"];
        $telefono=$_POST["telefono"];
        $correo=$_POST["correo"];
        $id = $_POST["id"];
        if ($activo!=1)
        {$activo=0;}
        
        $sql1 = "INSERT INTO usuarios (user, password, nombre, activo, direccion, telefono, correo) VALUES('$usuario', '$contrasena', '$nombre', '$activo', '$direccion', '$telefono', '$correo')";  
        
        $verificar= $mysqli->query("SELECT * FROM usuarios where user='$usuario'");
        if(mysqli_num_rows($verificar)>0)
        {
            header("Location:gestion_usuarios.php?idUsuario=$idUsuarios&variable=S3");
            exit;
        }
        $result1 = $mysqli->query($sql1);
        if(!$result1)
        {
            header("Location:gestion_usuarios.php?idUsuario=$idUsuarios&variable=S4"); 
        }else
        {
            header("Location:gestion_usuarios.php?idUsuario=$idUsuarios&variable=S5");
    
        }
        }
    }
?>
 	        
 	        <form method=POST action="agregar_usuario.php?idUsuario=<?php echo $idUsuarios ?>">
 	        <tr>	
      		    <td bgcolor="#CCEECC" align=center> 
			   	  <font color="#000044"> <b>Usuario: </b></font>  
				  </td>	
				  <td bgcolor="#EEEEEE" align=center> 
				    <input step="any" name="usuario" value="" required>  
                    </td>	
	                 </tr>
 	               <tr>	
      		        <td bgcolor="#CCEECC" align=center> 
			   	  <fontcolor="#000044" > <b>Contraseña:  </b></font>  
				  </td>	
				  <td bgcolor="#EEEEEE" align=center> 
				    <input type=password step="any" name="contrasena" value="" required >  
                </td>	
	     </tr>
	     <tr>	
      		        <td bgcolor="#CCEECC" align=center> 
			   	  <fontcolor="#000044" > <b>Nombre:  </b></font>  
				  </td>	
				  <td bgcolor="#EEEEEE" align=center> 
				    <input step="any" name="nombre" value="" required >  
                </td>	
	     </tr>
	     <tr>	
      		        <td bgcolor="#CCEECC" align=center> 
			   	  <fontcolor="#000044" > <b>Direccion:  </b></font>  
				  </td>	
				  <td bgcolor="#EEEEEE" align=center> 
				    <input step="any" name="direccion" value="" required >  
                </td>	
	     </tr>
	     <tr>	
      		        <td bgcolor="#CCEECC" align=center> 
			   	  <fontcolor="#000044" > <b>Telefono:  </b></font>  
				  </td>	
				  <td bgcolor="#EEEEEE" align=center> 
				    <input step="any" name="telefono" value="" required >  
                </td>	
	     </tr>
	     <tr>	
      		        <td bgcolor="#CCEECC" align=center> 
			   	  <fontcolor="#000044" > <b>Correo:  </b></font>  
				  </td>	
				  <td bgcolor="#EEEEEE" align=center> 
				    <input step="any" name="correo" value="" required >  
                </td>	
	     </tr>
	     <tr>	
      		        <td bgcolor="#CCEECC" align=center> 
			   	  <fontcolor="#000044" > <b>Estado: </b></font>  
				  </td>	
				  <td bgcolor="#EEEEEE" align=center> 
                    <label class= "switch">
                    <input type="checkbox" name="activo" <?php echo "checked"?>>
                    <span class= "slider"></span>
                     </label>
				      
                </td>	
	     </tr>
       <tr>	
				  <td bgcolor="#EEEEEE" align=center colspan=2> 
				  <input type="hidden" name="enviado" value="S1">  
				    <input type="hidden" name="id" value =<?php echo $id;?>>
				    <input type="submit" class="btn_form" value="Agregar" name="Actualizar">  
          </td>	
	     </tr>
      </form>	
            </table>    
          
      <iframe src="../menu.php?idUsuario=<?php echo $idUsuarios?>" class="menus"></iframe>
            
    
        </body>

   </html>