<?php
include "../../conexion.php";
$mysqli = new mysqli($host, $user, $pw, $db);
$idUsuarios = $_GET["idUsuario"];
$variable = $_POST["variable"];
?>

  <html>
    <head>
      <title> Gestion usuarios
		  </title>
      <meta http-equiv="refresh" content="30" />
      <link rel="stylesheet" type="text/css" href="gestion_usuarios.css" th:href="@{gestion_usuarios.css}"> 
    </head>
    <body class="gestion_usuarios">
      <iframe src="../menu.php?idUsuario=<?php echo $idUsuarios?>" class="menus"></iframe>
      <table cellpadding=5 border=1 class="tabla" align=center>
         
         <tr>
         <td  valign="top" align=center colspan=8>
           <h1> <font color=white>Administradores</font></h1>
         </td>
         </tr>
          <?php
               if ((isset($_GET["variable"])))  
               {
               $variable = $_GET["variable"];
               if ($variable == "S1")
                {
                     echo '<tr>	
                  		<td bgcolor="#13FF00" align=center colspan=8> 
            			   	  <font FACE="arial" SIZE=3 color="#000000"> <b>Administrador modificado correctamente</b></font>
            				  </td>	
            	     </tr>';
                }
                elseif($variable == "S2"){
                     echo '<tr>	
                  		<td bgcolor="#FF0000" align=center colspan=8> 
            			   	  <font FACE="arial" SIZE=3 color="#000000"> <b>El Administrador no pudo ser modificado</b></font>
            				  </td>	
            	     </tr>';
                }
                elseif($variable == "S3"){
                     echo '<tr>	
                  		<td bgcolor="#FF0000" align=center colspan=8> 
            			   	  <font FACE="arial" SIZE=3 color="#000000"> <b>El Administrador ya existe</b></font>
            				  </td>	
            	     </tr>';
                }
                elseif($variable == "S4"){
                     echo '<tr>	
                  		<td bgcolor="#FF0000" align=center colspan=8> 
            			   	  <font FACE="arial" SIZE=3 color="#000000"> <b>Error al agregar Administrador</b></font>
            				  </td>	
            	     </tr>';
                }
                elseif($variable == "S5"){
                     echo '<tr>	
                  		<td bgcolor="#13FF00" align=center colspan=8> 
            			   	  <font FACE="arial" SIZE=3 color="#000000"> <b>Administrador agregado correctamente</b></font>
            				  </td>	
            	     </tr>';
                }
               }
            ?>

    	 <tr>
         <td align=center bgcolor="#E1E1E1">
            <b>#</b>
         </td>
         <td align=center bgcolor="#E1E1E1">
            <b>Usuario</b>
         </td>
         <td align=center bgcolor="#E1E1E1">
            <b>Nombre</b>
         </td>
         <td align=center bgcolor="#E1E1E1">
            <b>Estado</b>
         </td>
         <td align=center bgcolor="#E1E1E1">
            <b>Telefono</b>
         </td>
         <td align=center bgcolor="#E1E1E1">
            <b>Direccion</b>
         </td>
         <td align=center bgcolor="#E1E1E1">
            <b>Correo</b>
         </td>
         <td align=center bgcolor="#E1E1E1">
            <b>Modificar</b>
         </td>
 	     </tr>
 	     
 	       
<?php
   
$sql1 = "SELECT * from usuarios";
$result1 = $mysqli->query($sql1);
while($row1 = $result1->fetch_array(MYSQLI_NUM))
{
 $id = $row1[0];
 $user = $row1[1];
 $nombre = $row1[3];
 $activo = $row1[4];
 $direccion = $row1[5];
 $telefono = $row1[6];
 $correo = $row1[7];
?>
<form method=POST action="modificar_usuario.php?idUsuario=<?php echo $idUsuarios?>">
    	 <tr>
         <td align=center bgcolor="#E1E1E1">
          <input type="hidden" name="id" value =<?php echo $id;?>>
           <?php echo $id; ?>
         </td>
         <td align=center bgcolor="#E1E1E1">
           <?php echo $user; ?> 
         </td>
         <td align=center bgcolor="#E1E1E1">
           <?php echo $nombre; ?> 
         </td>
         <td align=center bgcolor="#E1E1E1">
           <?php 
           if($activo==1){
                echo "Activo";
              }
              else if($activo != 1){
                echo "No activo";
              }
           ; ?>
           </td>
            </td>
         <td align=center bgcolor="#E1E1E1">
           <?php echo $telefono; ?> 
         </td>
          </td>
         <td align=center bgcolor="#E1E1E1">
           <?php echo $direccion; ?> 
         </td>
          </td>
         <td align=center bgcolor="#E1E1E1">
           <?php echo $correo; ?> 
         </td>
         <td align=center bgcolor="#E1E1E1">
            <input type="submit" class="btn_form" value="Modificar" name="Actualizar">
         </td>
 	     </tr>
 	     </form>
<?php
}
?>
<form method=POST action="agregar_usuario.php?idUsuario=<?php echo $idUsuarios?>">
</td>
         <td align=center bgcolor="#E1E1E1" colspan=8>
            <input type="submit" class="btn_form_a" value=" Agregar un nuevo Administrador " name="agregar">
         </td>
 	     </form>
     </body>
   </html>