<?php
include "../conexion.php";
$variablephp = "<script> document.write(idUsuario) </script>";
echo "variablephp =",$variablephp;

?>