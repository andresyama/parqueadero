<?php
include "../../conexion.php";
$mysqli = new mysqli($host, $user, $pw, $db);
$idUsuarios = $_GET["idUsuario"];
$id = $_POST["id"];
?>

  <html>
    <head>
      <title> Estado de los puestos
		  </title>
      <meta http-equiv="refresh" content="30" />
      <link rel="stylesheet" type="text/css" href="des_act.css" th:href="@{des_act.css}"> 
    </head>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js">
    </script>
    <body class="tabla_parqueaderos">
      <iframe src="../menu.php?idUsuario=<?php echo $idUsuarios?>" class="menus"></iframe>
      <table cellpadding=5 border=1 class="tabla">
        <td  align=center colspan=5  bgcolor="#151515">
          <h1> <font color=white>Disponibilidad Parqueadero 1</font></h1>
        </td> 	      
        <tr>
          <td align=center bgcolor="#E1E1E1">
              <b>#</b>
            </td>
          <td align=center bgcolor="#E1E1E1">
            <b>Parqueadero</b>
          </td>
          <td align=center bgcolor="#E1E1E1">
            <b>Numero de puesto</b>
          </td>
          <td align=center bgcolor="#E1E1E1">
            <b>Estado</b>
          </td>
 	      </tr>
        
         
<?php

if ((isset($_POST["enviado"])))  // Ingresa a este if si el formulario ha sido enviado..., al ingresar actualiza los datos ingresados en el formulario, en la base de datos.
  {
  $enviado = $_POST["enviado"];
  if ($enviado == "S1")
   {    
        $check1= isset($_POST["my_check_1"]);
        if ($check1!=1)
        { $check1=0;}

        $check2= isset($_POST["my_check_2"]);
        if ($check2!=1)
        { $check2=0;}

        $check3= isset($_POST["my_check_3"]);
        if ($check3!=1)
        { $check3=0;}

        $check4= isset($_POST["my_check_4"]);
        if ($check4!=1)
        { $check4=0;}
        
         $mysqli = new mysqli($host, $user, $pw, $db);          
         $sql1 = "UPDATE estados_puestos set estado=$check1, ocupacion=(1-$check1) where id=1";        
         $result1 = $mysqli->query($sql1);
         $sql1 = "UPDATE estados_puestos set estado=$check2, ocupacion=(1-$check2) where id=2";          
         $result1 = $mysqli->query($sql1);
         $sql1 = "UPDATE estados_puestos set estado=$check3, ocupacion=(1-$check3) where id=3";          
         $result1 = $mysqli->query($sql1);
         $sql1 = "UPDATE estados_puestos set estado=$check4, ocupacion=(1-$check4) where id=4";          
         $result1 = $mysqli->query($sql1);
         $id = $_POST["id"];

         if ($result1 == 1){
           header("Location:des_act.php?idUsuario=$idUsuarios&variable=S01");
            
          }
          else
             {
                header("Location:des_act.php?idUsuario=$idUsuarios&variable=S02");
          }
         
   } // FIN DEL IF, si ya se han recibido los datos del formulario
  }


?>
              <form method=POST action="des_act.php?idUsuario=<?php echo $idUsuarios ?>">   
<?php
$sql1 = "SELECT * from estados_puestos order by id LIMIT 4";
$result1 = $mysqli->query($sql1);
$contador = 0;
while($row1 = $result1->fetch_array(MYSQLI_NUM))
{
 $parqueadero = $row1[1];
 $num_puestos = $row1[3];
 $estado = $row1[4];
 $ocupacion = $row1[5];
 $contador++;
?>        
    

    	  <tr>
          <td align=center bgcolor="#E1E1E1">
            <?php echo $contador; ?> 
          </td>
          <td align=center bgcolor="#E1E1E1">
            <?php echo $parqueadero; ?> 
          </td>
          <td align=center bgcolor="#E1E1E1">
            <?php echo $num_puestos; ?> 
          </td>
          <td align=center bgcolor="#E1E1E1">
            <?php             
            if($estado==1){
                $e="checked";               
              }
              else if($estado != 1){
                $e="uchecked";
              }
            ;?>
            
            <label class= "switch">
            <input type="checkbox" id="my_check_<?php echo $num_puestos?>" onclick="$(this).val(this.checked ? 1 : 0)" name="my_check_<?php echo $num_puestos?>" <?php echo $e ?>>
            <span class= "slider"></span>
            </label>
            
          </td>         
 	      </tr>    
<?php
}
    if ((isset($_GET["variable"])))  
   {
   $variable = $_GET["variable"];
   if ($variable == "S01")
    {
         echo '<tr>	
      		<td bgcolor="#13FF00" align=center colspan=8> 
			   	  <font FACE="arial" SIZE=3 color="#000000"> <b>Datos actualizados correctamente</b></font>
				  </td>	
	     </tr>';
    }
    elseif($variable == "S02"){
         echo '<tr>	
      		<td bgcolor="#FF0000" align=center colspan=8> 
			   	  <font FACE="arial" SIZE=3 color="#000000"> <b>Problemas al actualiar datos</b></font>
				  </td>	
	     </tr>';
    }
    
   }
 
?>      
        <tr>	
          <td bgcolor="#EEEEEE" align=center colspan=4> 
				    <input type="hidden" name="enviado" value="S1">  
				    <input type="hidden" name="id" value =<?php echo $id;?>>
				    <input type="submit" class="btn_form" value="Actualizar" name="Actualizar">  
          </td>	
	      </tr>
        </form>
      </table>



      <table cellpadding=5 border=1 class="tabla">
        <td  align=center colspan=5  bgcolor="#151515">
          <h1> <font color=white>Disponibilidad Parqueadero 2</font></h1>
        </td> 	      
        <tr>
          <td align=center bgcolor="#E1E1E1">
              <b>#</b>
            </td>
          <td align=center bgcolor="#E1E1E1">
            <b>Parqueadero</b>
          </td>
          <td align=center bgcolor="#E1E1E1">
            <b>Numero de puesto</b>
          </td>
          <td align=center bgcolor="#E1E1E1">
            <b>Estado</b>
          </td>
 	      </tr>
        
         
<?php

if ((isset($_POST["enviado"])))  // Ingresa a este if si el formulario ha sido enviado..., al ingresar actualiza los datos ingresados en el formulario, en la base de datos.
  {
  $enviado = $_POST["enviado"];
  if ($enviado == "S2")
   {    
        $check1= isset($_POST["my_check_1"]);
        if ($check1!=1)
        { $check1=0;}

        $check2= isset($_POST["my_check_2"]);
        if ($check2!=1)
        { $check2=0;}

        $check3= isset($_POST["my_check_3"]);
        if ($check3!=1)
        { $check3=0;}

        $check4= isset($_POST["my_check_4"]);
        if ($check4!=1)
        { $check4=0;}
        
         $mysqli = new mysqli($host, $user, $pw, $db);          
         $sql1 = "UPDATE estados_puestos set estado=$check1, ocupacion=(1-$check1) where id=5";        
         $result1 = $mysqli->query($sql1);
         $sql1 = "UPDATE estados_puestos set estado=$check2, ocupacion=(1-$check2) where id=6";          
         $result1 = $mysqli->query($sql1);
         $sql1 = "UPDATE estados_puestos set estado=$check3, ocupacion=(1-$check3) where id=7";          
         $result1 = $mysqli->query($sql1);
         $sql1 = "UPDATE estados_puestos set estado=$check4, ocupacion=(1-$check4) where id=8";          
         $result1 = $mysqli->query($sql1);
         $id = $_POST["id"];

         if ($result1 == 1){
            header("Location:des_act.php?idUsuario=$idUsuarios&variable=S01");
            
          }
          else
             {
                header("Location:des_act.php?idUsuario=$idUsuarios&variable=S02");
          }
         
   } // FIN DEL IF, si ya se han recibido los datos del formulario
  }


?>
              <form method=POST action="des_act.php?idUsuario=<?php echo $idUsuarios ?>">   
<?php
$sql1 = "SELECT * from estados_puestos where id>4 order by id LIMIT 4";
$result1 = $mysqli->query($sql1);
$contador = 0;
while($row1 = $result1->fetch_array(MYSQLI_NUM))
{
 $parqueadero = $row1[1];
 $num_puestos = $row1[3];
 $estado = $row1[4];
 $ocupacion = $row1[5];
 $contador++;
?>        
    

    	  <tr>
          <td align=center bgcolor="#E1E1E1">
            <?php echo $contador; ?> 
          </td>
          <td align=center bgcolor="#E1E1E1">
            <?php echo $parqueadero; ?> 
          </td>
          <td align=center bgcolor="#E1E1E1">
            <?php echo $num_puestos; ?> 
          </td>
          <td align=center bgcolor="#E1E1E1">
            <?php             
            if($estado==1){
                $e="checked";               
              }
              else if($estado != 1){
                $e="uchecked";
              }
            ;?>            
            <label class= "switch">
            <input type="checkbox" id="my_check_<?php echo $num_puestos?>" onclick="$(this).val(this.checked ? 1 : 0)" name="my_check_<?php echo $num_puestos?>" <?php echo $e ?>>
            <span class= "slider"></span>
            </label>
          </td>         
 	      </tr>    
<?php
}
if ((isset($_GET["variable"])))  
   {
   $variable = $_GET["variable"];
   if ($variable == "S01")
    {
         echo '<tr>	
      		<td bgcolor="#13FF00" align=center colspan=8> 
			   	  <font FACE="arial" SIZE=3 color="#000000"> <b>Datos actualizados correctamente</b></font>
				  </td>	
	     </tr>';
    }
    elseif($variable == "S02"){
         echo '<tr>	
      		<td bgcolor="#FF0000" align=center colspan=8> 
			   	  <font FACE="arial" SIZE=3 color="#000000"> <b>Problemas al actualiar datos</b></font>
				  </td>	
	     </tr>';
    }
    
   }
?>      
        <tr>	
          <td bgcolor="#EEEEEE" align=center colspan=4> 
				    <input type="hidden" name="enviado" value="S2">  
				    <input type="hidden" name="id" value =<?php echo $id;?>>
				    <input type="submit" class="btn_form" value="Actualizar" name="Actualizar">  
          </td>	
	      </tr>
        </form>
      </table>




     </body>
     
   </html>