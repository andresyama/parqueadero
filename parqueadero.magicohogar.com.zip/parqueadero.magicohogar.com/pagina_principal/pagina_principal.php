<?php
include "../conexion.php";
$idUsuarios = $_GET["idUsuario"];
?>
 
  <html>
    <head>
       <link rel="stylesheet" type="text/css" href="pagina_principal.css" th:href="@{pagina_principal.css}">  
                         
    </head>
        <body class="pagina_principal">
        
        <iframe src="menu.php?idUsuario=<?php echo $idUsuarios?>" class="menus"></iframe>
        <div class="informacion_admin">
              
             <h1> <font><center>DATOS DEL ADMINISTRADOR</center></font></h1>
             <?php
              $mysqli = new mysqli($host, $user, $pw, $db);
              $sql1 = "SELECT * from usuarios where idUsuario=$idUsuarios"; 
              $result1 = $mysqli->query($sql1);
              $row1 = $result1->fetch_array(MYSQLI_NUM);
              $nombre = $row1[3];
              $usuario = $row1[1];
              $tipo = $row1[4];
              $direccion = $row1[5];
              $telefono = $row1[6];
              $correo = $row1[7];
              echo "Nombre: ",$nombre; 
              echo "<BR><BR>";
              echo "Usuario: ",$usuario;
              echo "<BR><BR>";
              if($tipo==1){
                echo "Administrador activo";
              }
              else if($tipo != 1){
                echo "Administrador no activo";
              }
              echo "<BR><BR>";
              echo "Direccion: ",$direccion; 
              echo "<BR><BR>";
              echo "Telefono: ",$telefono;
              echo "<BR><BR>";
               echo "Correo: ",$correo;
              
            ?>
        </div>
        </body>
        
        </script>
   </html>