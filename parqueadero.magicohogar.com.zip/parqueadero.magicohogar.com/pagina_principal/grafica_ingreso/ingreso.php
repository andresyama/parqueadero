<?php
include "../../conexion.php";
$idUsuarios = $_GET["idUsuario"];
?>
 
<!DOCTYPE html>
  <html lang='es'>
    <head>
        <link rel="stylesheet" type="text/css" href="ingreso.css" th:href="@{ingreso.css}">  
                            
    </head>
        <body class="ingreso">
      <iframe src="../menu.php?idUsuario=<?php echo $idUsuarios?>" class="menus"></iframe>


            <table class="tabla" align=center> 
            <tr> 
            <td valign="top" align=center colspan=6>
                <h1> <font color=white>Gestion ingreso vehiculos</font></h1>
            </td>
 	        </tr>
 	        

        <form method=POST action="ingreso_prueba.php?idUsuario=<?php echo $idUsuarios?>">
 	     <tr>	
      		<td bgcolor="#CCEECC" align=center> 
    		   	<font FACE="arial" SIZE=2 color="#004400"> <b>Parquedero:</b></font>  
    			</td>	
    			<td bgcolor="#EEEEEE" align=center> 
    			    <input type="radio" name="num_par" value="1" checked> Parqueadero 1<br>
                    <input type="radio" name="num_par" value="2"> Parqueadero 2<br>
                </td>	
	     </tr>
 	     <tr>	
      		<td bgcolor="#CCEECC" align=center> 
			   	  <font FACE="arial" SIZE=2 color="#004400"> <b>Fecha Inicial:</b></font>  
				  </td>	
				  <td bgcolor="#EEEEEE" align=center> 
				    <input type="date" name="fecha_ini" value="" required>  
          </td>	
	     </tr>
 	     <tr>	
      		<td bgcolor="#CCEECC" align=center> 
			   	  <font FACE="arial" SIZE=2 color="#004400"> <b>Fecha Final:</b></font>  
				  </td>	
				  <td bgcolor="#EEEEEE" align=center> 
				    <input type="date" name="fecha_fin" value="" required>  
          </td>	
	     </tr>
       <tr>	
				   <td bgcolor="#EEEEEE" align=center colspan=2> 
			    <input type="hidden" name="enviado" value="S1"> 
			    <input type="hidden" name="id" value =<?php echo $id;?>>
			    <input type="submit" class="btn_form" value="Consultar" name="Actualizar"> 
          </td>	
	     </tr>
      </form>
          	
              
          
      <iframe src="../menu.php?idUsuario=<?php echo $idUsuarios?>" class="menus"></iframe>
            
    
        </body>
       
   </html>