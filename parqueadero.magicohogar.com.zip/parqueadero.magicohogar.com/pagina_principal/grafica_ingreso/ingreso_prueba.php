<?php
include "../../conexion.php";
$mysqli = new mysqli($host, $user, $pw, $db);
$idUsuarios = $_GET["idUsuario"];
?>
 
<!DOCTYPE html>
  <html lang='es'>
    <head>
        <link rel="stylesheet" type="text/css" href="ingreso.css" th:href="@{ingreso.css}">
    </head>
        <body class="ingreso">
      <iframe src="../menu.php?idUsuario=<?php echo $idUsuarios?>" class="menus"></iframe>

            <table class="tabla" align=center> 
            <tr> 
            <td valign="top" align=center colspan=6>
                <h1> <font color=white>Gestion ingreso</font></h1>
            </td>
 	        </tr>
 	         <tr>
             <td align=center bgcolor="#E1E1E1">
                <b>Parqueadero</b>
             </td>
             <td align=center bgcolor="#E1E1E1">
                <b>Fecha</b>
             </td>
             <td align=center bgcolor="#E1E1E1">
                <b>Cantidad de vehiculos que ingresaron</b>
             </td>
     	     </tr>

<?php
   $fecha_ini = $_POST["fecha_ini"];  
   $fecha_fin = $_POST["fecha_fin"];
   $num_par= $_POST["num_par"];

$sql1 = "SELECT fecha,COUNT(Parqueadero) as total from pago WHERE Parqueadero='$num_par' and fecha >= '$fecha_ini' and fecha <= '$fecha_fin' GROUP BY fecha";
$result1 = $mysqli->query($sql1);
while($row1 = $result1->fetch_array(MYSQLI_NUM))
{
 $total = $row1[1];
 $fecha = $row1[0];
?>
    	 <tr align=center bgcolor="#E1E1E1">
         <td valign="top" align=center>
           <?php echo $num_par; ?> 
         </td>
         <td valign="top" align=center>
           <?php echo $fecha; ?> 
         </td>
          <td valign="top" align=center>
           <?php echo $total; ?> 
         </td>
 	     </tr>
<?php
}  // FIN DEL WHILE
?>    

      <iframe src="../menu.php?idUsuario=<?php echo $idUsuarios?>" class="menus"></iframe>
        </body>
   </html>