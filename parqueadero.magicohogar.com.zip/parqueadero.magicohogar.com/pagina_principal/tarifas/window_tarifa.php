<?php
include "../../conexion.php";
$idUsuarios = $_GET["idUsuario"];
$id = $_POST["id"];
?>
 
<!DOCTYPE html>
  <html lang='es'>
    <head>
        <meta charset="UTF-8">
        <link rel="stylesheet" type="text/css" href="window_tarifa.css" th:href="@{window_tarifa.css}">  
                            
    </head>
        <body class="window_tarifa">


            <table class="tabla" align=center> 
            <tr> 
            <td valign="top" align=center colspan=6>
                <h1> <font color=white>Consulta y Modificacion de Tarifas</font></h1>
            </td>
 	        </tr>
 	        
<?php
 if ((isset($_POST["enviado"])))  
   {
   $enviado = $_POST["enviado"];
   if ($enviado == "S1")
    {
          $t1 = $_POST["tarifa1"];  
          $t2 = $_POST["tarifa2"];
          $id = $_POST["id"];
          $mysqli = new mysqli($host, $user, $pw, $db); 
          $sql1 = "UPDATE tarifas set valor_tarifa='$t1' where id=1";  
          $result1 = $mysqli->query($sql1);

          $sql2 = "UPDATE tarifas set valor_tarifa='$t2' where id=2"; 
          $result2 = $mysqli->query($sql2);

          if (($result1 == 1)&&($result2 == 1)){
           header("Location:window_tarifa.php?idUsuario=$idUsuarios&variable=S10");
            
          }
          else
             {
                header("Location:window_tarifa.php?idUsuario=$idUsuarios&variable=S11");
          }

    } // FIN DEL IF, si ya se han recibido los datos del formulario
   }  // FIN DEL IF, si la variable enviado existe, que es cuando ya se env�o el formulario
  
// AQUI CONSULTA LOS VALORES ACTUALES DE LAS TARIFAS, PARA PRESENTARLOS EN EL FORMULARIO

// CONSULTA TARIFA 1
$mysqli = new mysqli($host, $user, $pw, $db); 
$sql1 = "SELECT * from tarifas where id=1"; 
$result1 = $mysqli->query($sql1);
$row1 = $result1->fetch_array(MYSQLI_NUM);
$t1 = $row1[2];  

// CONSULTA TARIFA 2
$sql2 = "SELECT * from tarifas where id=2"; 
$result2 = $mysqli->query($sql2);
$row2 = $result2->fetch_array(MYSQLI_NUM);
$t2 = $row2[2];  

    if ((isset($_GET["variable"])))  
   {
       $variable = $_GET["variable"];
       if ($variable == "S10")
        {
             echo '<tr>	
          		<td bgcolor="#13FF00" align=center colspan=8> 
    			   	  <font FACE="arial" SIZE=3 color="#000000"> <b>Tarifa modificada correctamente</b></font>
    				  </td>	
    	     </tr>';
        }
        elseif($variable == "S11"){
             echo '<tr>	
          		<td bgcolor="#FF0000" align=center colspan=8> 
    			   	  <font FACE="arial" SIZE=3 color="#000000"> <b>La tarifa no pudo ser modificada</b></font>
    				  </td>	
    	     </tr>';
        }
    
   }
?>
 	        
 	        <form method=POST action="window_tarifa.php?idUsuario=<?php echo $idUsuarios ?>">
 	        <tr>	
      		    <td bgcolor="#CCEECC" align=center> 
			   	  <font FACE="arial" SIZE=2 color="#000044"> <b>Tarifa parqueadero 1: </b></font>  
				  </td>	
				  <td bgcolor="#EEEEEE" align=center> 
				    <input step="any" name="tarifa1" placeholder="$" value="<?php echo $t1; ?>" required>  
                    </td>	
	                 </tr>
 	               <tr>	
      		<td bgcolor="#CCEECC" align=center> 
			   	  <font FACE="arial" SIZE=2 color="#000044" > <b>Tarifa parqueadero 2: </b></font>  
				  </td>	
				  <td bgcolor="#EEEEEE" align=center> 
				    <input step="any" name="tarifa2" value="<?php echo $t2; ?>" required >  
          </td>	
	     </tr>
       <tr>	
				  <td bgcolor="#EEEEEE" align=center colspan=2> 
				    <input type="hidden" name="enviado" value="S1">  
				    <input type="hidden" name="id" value =<?php echo $id;?>>
				    <input type="submit" class="btn_form" value="Actualizar" name="Actualizar">  
          </td>	
	     </tr>
      </form>	
            </table>    
          
            <iframe src="../menu.php?idUsuario=<?php echo $idUsuarios ?>" class="menus"></iframe>  
            
    
        </body>
        
   </html>