let boton = document.getElementById("btn-login");
let user = document.getElementById("txt-usuario");
let password = document.getElementById("txt-password");
const container = document.querySelector(".login");

boton.addEventListener('click', (e)=>{
    data();
})


function data(){
    let datos = new FormData();
    datos.append("user",user.value);
    datos.append("password", password.value);
    fetch('validacion.php',{
        method:'POST',
        body:datos 
    }).then(Response => Response.json())
    .then(({success, idUsuario, activo}) =>{
        
        console.log(activo, idUsuario)
        setTimeout(() => {
            
        }, 20000);
        if(success === 1){
            localStorage.setItem('ingreso', 'confirmado');
            location.href = `/pagina_principal/pagina_principal.php?idUsuario=${idUsuario}&activo=${activo}`;
        } else  {
            if (success == 0) {
                alertaDatos("usuario inactivo, por favor hable con un administrador");
                container.reset();
            }
            else {
                alertaDatos("Usuario o contraseña invalidos");
                container.reset();
            }
        }
    })
    .catch(e =>{
        console.log(e);
    })
}

function alertaDatos (mensaje){
    const alertaLogin = document.createElement('div');
    
    alertaLogin.innerHTML = `<div class="alert alert-danger mt-2 text-center col-9 px-0 alert-dismissible fade show" role="alert">
        <strong>${mensaje}</strong>

        </div>`;
        container.appendChild(alertaLogin)
        setTimeout(() => {
            alertaLogin.remove();
        }, 2000);
}
