<?php
    include('conexion.php');
    $query = "SELECT * FROM ubicacion_parqueadero";
    $result = mysqli_query($connection, $query);
    $respuesta = $result->fetch_array(MYSQLI_NUM);

    echo json_encode(array('resultado'=>$respuesta));

?>
    
	
