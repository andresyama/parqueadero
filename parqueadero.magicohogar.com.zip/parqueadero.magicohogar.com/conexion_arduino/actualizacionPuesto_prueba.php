<?php
include "conexion.php";  // Conexi�n tiene la informaci�n sobre la conexi�n de la base de datos.

$ocupacion_puesto1 = $_GET["oc"];
$puesto1 = $_GET["puesto1"];
$ocupacion_puesto2 = $_GET["oc2"];
$puesto2 = $_GET["puesto2"];
$parqueadero = $_GET["parq"];
echo $ocupacion_puesto1;
$mysqli = new mysqli($host, $user, $pw, $db); // Aqu� se hace la conexi�n a la base de datos.

$sql1 = "SELECT ocupacion,fecha_inicio,estado FROM estados_puestos WHERE parqueadero=$parqueadero AND idPuesto=$puesto1";
$result=$mysqli->query($sql1);
$registro1 = $result->fetch_array(MYSQLI_NUM);
$ocupacion_inicial1 = $registro1[0];
$fecha_inicio1 = $registro1[1];
$estado1=$registro1[2];

$sql2 = "SELECT ocupacion,fecha_inicio,estado FROM estados_puestos WHERE parqueadero=$parqueadero AND idPuesto=$puesto2";
$result2=$mysqli->query($sql2);
$registro2 = $result2->fetch_array(MYSQLI_NUM);
$ocupacion_inicial2 = $registro2[0];
$fecha_inicio2 = $registro2[1];
$estado2=$registro2[2];

date_default_timezone_set('America/Bogota'); 

if($estado1 == '1')
{

    if($ocupacion_inicial1 != $ocupacion_puesto1)
    {
        $fecha_actual = date("Y-m-d H:i:s");
    
        if($ocupacion_puesto1==0 && $ocupacion_inicial1==1)
        {
            $sql = "UPDATE estados_puestos SET ocupacion=$ocupacion_puesto1, fecha_inicio='$fecha_actual' WHERE  parqueadero=$parqueadero AND idPuesto=$puesto1";
            $result = $mysqli->query($sql);
        }
        elseif($ocupacion_puesto1==1 && $ocupacion_inicial1==0)
        {
            $sql = "UPDATE estados_puestos SET ocupacion=$ocupacion_puesto1, fecha_salida='$fecha_actual' WHERE parqueadero=$parqueadero  AND idPuesto=$puesto1";
            $result = $mysqli->query($sql);
            
            $date1 = strtotime($fecha_inicio1);
            $date2 = strtotime($fecha_actual);
            $hora_uso = round((($date2-$date1)/3600),2);
            $sql2 = "INSERT INTO historiales_uso (parqueadero, puesto, fecha_inicio1, fecha_salida, hora_uso) VALUES ($parqueadero, $puesto1, '$fecha_inicio','$fecha_actual',$hora_uso)";
            $result2 = $mysqli->query($sql2);
        }
    }
}


if($estado2 == '1')
{
    if($ocupacion_inicial2 != $ocupacion_puesto2)
    {
        $fecha_actual = date("Y-m-d H:i:s");
    
        if($ocupacion_puesto2==0 && $ocupacion_inicial2==1)
        {
            $sql = "UPDATE estados_puestos SET ocupacion=$ocupacion_puesto2, fecha_inicio='$fecha_actual' WHERE  parqueadero=$parqueadero AND idPuesto=$puesto2";
            $result = $mysqli->query($sql);
        }
        elseif($ocupacion_puesto2==1 && $ocupacion_inicial2==0)
        {
            $sql = "UPDATE estados_puestos SET ocupacion=$ocupacion_puesto2, fecha_salida='$fecha_actual' WHERE parqueadero=$parqueadero  AND idPuesto=$puesto2";
            $result = $mysqli->query($sql);
            
            $date1 = strtotime($fecha_inicio1);
            $date2 = strtotime($fecha_actual);
            $hora_uso = round((($date2-$date1)/3600),2);
            $sql2 = "INSERT INTO historiales_uso (parqueadero, puesto, fecha_inicio, fecha_salida, hora_uso) VALUES ($parqueadero, $puesto2, '$fecha_inicio2','$fecha_actual',$hora_uso)";
            $result2 = $mysqli->query($sql2);
        }
    }
}
?>
