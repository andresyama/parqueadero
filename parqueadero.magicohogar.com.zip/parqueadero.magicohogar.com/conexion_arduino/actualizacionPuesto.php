<?php
include "conexion.php";  // Conexi�n tiene la informaci�n sobre la conexi�n de la base de datos.

$ocupacion = $_GET["oc"];
$parqueadero = $_GET["parqueadero"];
$id_tarj = $_GET["ID_TARJ"];
$puesto = $_GET["puesto"];


$mysqli = new mysqli($host, $user, $pw, $db); // Aqu� se hace la conexi�n a la base de datos.

$sql1 = "SELECT ocupacion,fecha_inicio FROM estados_puestos WHERE parqueadero=$parqueadero AND ID_TARJ = $id_tarj AND idPuesto=$puesto";
$result1=$mysqli->query($sql1);
$registro = $result1->fetch_array(MYSQLI_NUM);
$ocupacionInicial = $registro[0];
$fecha_inicio = $registro[1];
date_default_timezone_set('America/Bogota'); 

if($ocupacionInicial != $ocupacion)
{
   
    $fecha_actual = date("Y-m-d H:i:s");
    
    if($ocupacion==0 && $ocupacionInicial==1)
    {
        $sql = "UPDATE estados_puestos SET ocupacion=$ocupacion, fecha_inicio='$fecha_actual' WHERE  parqueadero=$parqueadero AND ID_TARJ = $id_tarj AND idPuesto=$puesto";
        $result = $mysqli->query($sql);
    }
    elseif($ocupacion==1 && $ocupacionInicial==0)
    {
        $sql1 = "UPDATE estados_puestos SET ocupacion=$ocupacion, fecha_salida='$fecha_actual' WHERE parqueadero=$parqueadero AND ID_TARJ = $id_tarj AND idPuesto=$puesto";
        $result = $mysqli->query($sql1);
        
        $date1 = strtotime($fecha_inicio);
        $date2 = strtotime($fecha_actual);
        $hora_uso = round((($date2-$date1)/3600),2);
        $sql2 = "INSERT INTO historiales_uso (parqueadero, puesto, fecha_inicio, fecha_salida, hora_uso) VALUES ($parqueadero, $puesto, '$fecha_inicio','$fecha_actual',$hora_uso)";
        $result2 = $mysqli->query($sql2);
    }
}
?>
