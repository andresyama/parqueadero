<?php
include "conexion.php";  // Conexi�n tiene la informaci�n sobre la conexi�n de la base de datos.

$parqueadero = $_GET["parqueadero"];
$id_tarj = $_GET["ID_TARJ"];
$puesto = $_GET["puesto"];

// CONSULTA ESTADO DE PUESTO
$mysqli = new mysqli($host, $user, $pw, $db); 
$sql = "SELECT estado FROM estados_puestos WHERE (parqueadero=$parqueadero AND ID_TARJ = $id_tarj AND idPuesto=$puesto)"; 
$result = $mysqli->query($sql);
$registro = $result->fetch_array(MYSQLI_NUM);
$estado = $registro[0];

echo "estado".$estado; 
?>

